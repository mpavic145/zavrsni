			<div data-role="footer" data-position="fixed" data-fullscreen="true" style="text-align:center;overflow:hidden;height:4em;opacity:1;">
				<div data-role="controlgroup" data-type="horizontal">
					<a href="/attacks" class="ui-btn ui-corner-all ui-shadow ui-icon-myicon ui-btn-icon-top" style="background-color:#e9e9e9;border-style:none;padding-right:1em;padding-left:1em;" rel="external"> <?php echo $lang["attacks"]; ?> </a>
					<a href="/contact" class="ui-btn ui-corner-all ui-shadow ui-icon-mail ui-btn-icon-top" style="background-color:#e9e9e9;border-style:none;padding-right:1em;padding-left:1em;" rel="external"> <?php echo $lang["contact"]; ?> </a>
					<a href="/about" class="ui-btn ui-corner-all ui-shadow ui-icon-user ui-btn-icon-top" style="background-color:#e9e9e9;border-style:none;padding-right:1em;padding-left:1em;" rel="external"> <?php echo $lang["about"]; ?> </a>
				</div>
			</div>
		</div>
	</body>
