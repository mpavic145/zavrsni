		<div data-role="main" class="ui-content" style="padding:1em;">
			<u> <?php echo $lang["author"]; ?> </u><br><br>
			<?php echo $lang["about_author"]; ?>
			<br><br><u> TVZ </u><br><br>
			<?php echo $lang["about_tvz"]; ?>
			<br><br><u> <?php echo $lang["goal"]; ?> </u><br><br>
			<?php echo $lang["about_goal"]; ?>
  		</div>