	<body>
		<div data-role="page" id="pagge">
			<div data-role="header" style="overflow:hidden;height:4em;">
				<picture>
				  <source media="(min-width: 650px)" srcset="../img/logo_long.png" alt="WIKIAttacks_logo" style="height:4em;padding-left:1em;">
				  <source media="(min-width: 300px)" srcset="../img/logo.png" alt="WIKIAttacks_logo" style="height:4em;padding-left:0.1em;">
				  <img src="../img/logo.png" alt="WIKIAttacks_logo" style="height:4em">
				</picture>
				<form method="post" action="#" style="height:2em;padding-right:5em;margin-top:1.3em;display:inline;" class="ui-btn-right" rel="external">
					<input type="submit" name="jezik" id="jezik" value="hrv" style="background-image:url(../img/hr.png);background-size:100% 100%;background-repeat:no-repeat;opacity:1;">
					<input type="submit" name="jezik" id="jezik" value="eng" style="background-image:url(../img/eng.png);background-size:100% 100%;background-repeat:no-repeat;opacity:1;">
				</form>
				<a href="../home" class="ui-btn-right ui-btn ui-shadow ui-corner-all ui-icon-home ui-btn-icon-notext" rel="external" style="margin-top: 1em; margin-right: 1em;"> Home </a>
			</div>
