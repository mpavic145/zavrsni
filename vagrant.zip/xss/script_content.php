		<div data-role="main" class="ui-content" style="padding:1em;">
			<h3> Cross-site Scripting </h3>
			<?php
				$files = ["../require/idiorm.php", "../require/library/HTMLPurifier.auto.php"];

				foreach ($files as $file) 
				{
					if (!is_readable($file)) 
					{
						http_response_code(503);
						echo '<h1>503 Service Unavailable</h1>';
					}
				}

				foreach ($files as $file) 
				{
					require $file;
				}
				
				$purifier = new HTMLPurifier();
				$tag = "xss";
				
				switch($_COOKIE["language"])
				{
					case "hrvatski":
						$jezik= "hrv";
						break;
					case "english":
						$jezik= "eng";
						break;
					default:
						$jezik= "hrv";
				}
				
				try
				{
					ORM::configure(array(
						'connection_string' => 'mysql:host=localhost;dbname=zavrsni',
						'username' => 'inf',
						'password' => 'opis'));
					ORM::configure('return_result_sets', true);
					ORM::configure('driver_options', array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
					ORM::configure('error_mode', PDO::ERRMODE_EXCEPTION);
									
					$query = ORM::for_table('opce_informacije')->where(array('Lang' => $jezik,'Tag' => $tag))->find_one();
					
					$clean_html = $purifier->purify($query->Info);

					echo $clean_html;
				}
				catch(PDOException $e)
				{
					echo $lang["db_error"];
				}
				catch (Exception $e) 
				{
				  echo $lang["db_error"];
				}
			?>
			<h3> <?php echo $lang["types"];?> </h3>
			<u> DOM BASED XSS (TYPE-0 XSS) </u><br><br>
			<?php		
				$tag = "xss_type0";

				try
				{									
					$query = ORM::for_table('opce_informacije')->where(array('Lang' => $jezik,'Tag' => $tag))->find_one();
					
					$clean_html = $purifier->purify($query->Info);

					echo $clean_html;
				}
				catch(PDOException $e)
				{
					echo $lang["db_error"];
				}
				catch (Exception $e) 
				{
				  echo $lang["db_error"];
				}
			?>
			<br><br><u> Stored XSS (type-1 XSS) </u><br><br>
			<?php
				$tag = "xss_type1";

				try
				{
					$query = ORM::for_table('opce_informacije')->where(array('Lang' => $jezik,'Tag' => $tag))->find_one();
					
					$clean_html = $purifier->purify($query->Info);

					echo $clean_html;
				}
				catch(PDOException $e)
				{
					echo $lang["db_error"];
				}
				catch (Exception $e) 
				{
				  echo $lang["db_error"];
				}
			?>
			<br><br><u> Reflected XSS (type-2 XSS) </u><br><br>
			<?php
				$tag = "xss_type2";

				try
				{
					$query = ORM::for_table('opce_informacije')->where(array('Lang' => $jezik,'Tag' => $tag))->find_one();
					
					$clean_html = $purifier->purify($query->Info);

					echo $clean_html;
				}
				catch(PDOException $e)
				{
					echo $lang["db_error"];
				}
				catch (Exception $e) 
				{
				  echo $lang["db_error"];
				}

				echo '<br><br>'.$lang["more"].' '.'<div align="center"><br><a class="ui-btn ui-icon-action ui-btn-inline ui-btn-icon-right ui-corner-all ui-corner-all" href="https://www.owasp.org/index.php/Cross-site_Scripting_(XSS)">OWASP</a></div>';
			?>	
			<br><a class="ui-btn ui-icon-carat-r ui-btn-icon-right ui-corner-all ui-btn-inline" style="float:right" href="examples" rel="external"> <?php echo $lang["examples"]; ?> </a>
  		</div>