	<link rel="stylesheet" type="text/css" href="../styl/oblikovanje.css"/>
		<link rel="stylesheet" href="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.css">
		<script src="https://code.jquery.com/jquery-1.11.3.min.js"></script>
		<script src="https://code.jquery.com/mobile/1.4.5/jquery.mobile-1.4.5.min.js"></script>
		<meta name="Keywords" content="Web aplikacija,Primjeri napada,Završni rad,TVZ,SQL Injection,Cross-site Scripting,XSS"/>
		<meta name="Keywords" content="Web application,Examples of attack,Bachelor thesis,TVZ,SQL Injection,Cross-site Scripting,XSS"/>
		<meta name="Author" content="Marko Pavić"/>
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<meta charset="UTF-8">
	</head>
