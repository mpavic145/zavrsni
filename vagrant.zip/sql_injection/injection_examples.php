<?php
	$files = ["../require/detection.php", "../require/kolacic.php"];

	foreach ($files as $file) 
	{
		if (!is_readable($file)) 
		{
			http_response_code(503);
			echo '<h1>503 Service Unavailable</h1>';
			exit();
		}
	}

	foreach ($files as $file) 
	{
		require $file;
	}
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Home</title>
	<?php
		$files = ["../require/head.php", "../require/header.php", "injection_examples_content.php", "../require/footer.php"];
		
		foreach ($files as $file) 
		{
			if (!is_readable($file)) 
			{
				http_response_code(503);
				echo '<h1>503 Service Unavailable</h1>';
				exit();
			}
		}

		foreach ($files as $file) 
		{
			require $file;
		}
	?>
</html>
