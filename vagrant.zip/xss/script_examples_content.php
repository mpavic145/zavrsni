		<div data-role="main" class="ui-content" style="padding:1em;">
		
			<?php echo $lang["instructions"] ?>
		
			<form method="post" action="#" rel="external">
				<fieldset class="ui-field-contain">
					<label for="xss"> <?php echo $lang["code"] ?> </label>
					<select name="xss" id="xss">
						<option value="example_0"> DOM BASED XSS (TYPE-0 XSS) </option>
						<option value="example_1"> Stored XSS (type-1 XSS) </option>
						<option value="example_2"> Reflected XSS (type-2 XSS) </option>
					</select>
				</fieldset>
				<input type="submit" value=" <?php echo $lang["submit"] ?> " data-icon="check" data-iconpos="right" data-inline="true">
				<br><hr>
			</form>

		
			<?php
			
				if(isset($_POST["xss"]))
				{	
					switch($_COOKIE["language"])
					{
						case "hrvatski":
							$jezik= "hrv";
							break;
						case "english":
							$jezik= "eng";
							break;
						default:
							$jezik= "hrv";
					}
					
					switch($_POST["xss"])
					{
						case "example_0":
						{
							echo '<h3>'.$lang["example_number0"].'</h3>';
							echo $lang["example0_xss_text_1"].'<br>';
							switch($jezik)
							{
								case "eng":
								{
									echo '<img src="../img/dom_xss_code.png" style="width:100%;"><br>';
									echo $lang["example0_xss_text_2"].'<br>';
									echo '<img src="../img/dom_xss_url.png" style="width:100%;"><br>';
									echo $lang["example0_xss_text_3"].'<br>';
									echo '<img src="../img/dom_xss_uri.png" style="width:100%;"><br>';
									echo $lang["example0_xss_text_4"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example0_xss_metod1"].'</u><br><br>';
									echo $lang["example0_xss_text_5"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod2"].'</u><br><br>';
									echo $lang["example0_xss_text_6"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod3"].'</u><br><br>';
									echo $lang["example0_xss_text_7"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod4"].'</u><br><br>';
									echo $lang["example0_xss_text_8"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod5"].'</u><br><br>';
									echo $lang["example0_xss_text_9"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod6"].'</u><br><br>';
									echo $lang["example0_xss_text_10"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod7"].'</u><br><br>';
									echo $lang["example0_xss_text_11"].'<br>';
								}
								break;
								default:
								{
									echo '<img src="../img/dom_xss_code.png" style="width:100%;"><br>';
									echo $lang["example0_xss_text_2"].'<br>';
									echo '<img src="../img/dom_xss_url.png" style="width:100%;"><br>';
									echo $lang["example0_xss_text_3"].'<br>';
									echo '<img src="../img/dom_xss_uri.png" style="width:100%;"><br>';
									echo $lang["example0_xss_text_4"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example0_xss_metod1"].'</u><br><br>';
									echo $lang["example0_xss_text_5"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod2"].'</u><br><br>';
									echo $lang["example0_xss_text_6"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod3"].'</u><br><br>';
									echo $lang["example0_xss_text_7"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod4"].'</u><br><br>';
									echo $lang["example0_xss_text_8"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod5"].'</u><br><br>';
									echo $lang["example0_xss_text_9"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod6"].'</u><br><br>';
									echo $lang["example0_xss_text_10"].'<br><br>';
									echo '<u>'.$lang["example0_xss_metod7"].'</u><br><br>';
									echo $lang["example0_xss_text_11"].'<br>';
								}
							}
						}
							break;

						case "example_1":
						{	
							echo '<h3>'.$lang["example_number1"].'</h3>';
							echo $lang["example1_xss_text_1"].'<br>';
							switch($jezik)
							{
								case "eng":
								{
									echo '<img src="../img/stored_xss_form_eng.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/stored_xss_form_code_eng.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_2"].'<br>';
									echo '<img src="../img/stored_xss_database_eng.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_3"].'<br>';
									echo '<img src="../img/stored_xss_php_eng.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_4"].'<br>';
									echo '<img src="../img/stored_xss_cookie_eng.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_5"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example1_xss_metod1"].'</u><br><br>';
									echo $lang["example1_xss_text_6"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod2"].'</u><br><br>';
									echo $lang["example1_xss_text_7"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod3"].'</u><br><br>';
									echo $lang["example1_xss_text_8"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod4"].'</u><br><br>';
									echo $lang["example1_xss_text_9"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod5"].'</u><br><br>';
									echo $lang["example1_xss_text_10"].'<br>';
								}
								break;
								default:
								{
									echo '<img src="../img/stored_xss_form.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/stored_xss_form_code.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_2"].'<br>';
									echo '<img src="../img/stored_xss_database.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_3"].'<br>';
									echo '<img src="../img/stored_xss_php.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_4"].'<br>';
									echo '<img src="../img/stored_xss_cookie.png" style="width:100%;"><br>';
									echo $lang["example1_xss_text_5"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example1_xss_metod1"].'</u><br><br>';
									echo $lang["example1_xss_text_6"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod2"].'</u><br><br>';
									echo $lang["example1_xss_text_7"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod3"].'</u><br><br>';
									echo $lang["example1_xss_text_8"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod4"].'</u><br><br>';
									echo $lang["example1_xss_text_9"].'<br><br>';
									echo '<u>'.$lang["example1_xss_metod5"].'</u><br><br>';
									echo $lang["example1_xss_text_10"].'<br>';
								}
							}
						}
							break;
						
						case "example_2":
						{
							echo '<h3>'.$lang["example_number2"].'</h3>';
							echo $lang["example2_xss_text_1"].'<br>';
							switch($jezik)
							{
								case "eng":
								{
									echo '<img src="../img/reflective_xss_search_form_eng.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/reflective_xss_search_query_eng.png" style="width:100%;"><br>';
									echo $lang["example2_xss_text_2"].'<br>';
									echo '<img src="../img/reflective_xss_search_php_eng.png" style="width:100%;"><br>';
									echo $lang["example2_xss_text_3"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example2_xss_metod1"].'</u><br><br>';
									echo $lang["example2_xss_text_4"].'<br><br>';
									echo '<u>'.$lang["example2_xss_metod2"].'</u><br><br>';
									echo $lang["example2_xss_text_5"].'<br><br>';
									echo '<u>'.$lang["example2_xss_metod3"].'</u><br><br>';
									echo $lang["example2_xss_text_6"].'<br><br>';
									echo '<u>'.$lang["example2_xss_metod4"].'</u><br><br>';
									echo $lang["example2_xss_text_7"].'<br>';										
								}
								break;
								default:
								{
									echo '<img src="../img/reflective_xss_search_form.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/reflective_xss_search_query.png" style="width:100%;"><br>';
									echo $lang["example2_xss_text_2"].'<br>';
									echo '<img src="../img/reflective_xss_search_php.png" style="width:100%;"><br>';
									echo $lang["example2_xss_text_3"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example2_xss_metod1"].'</u><br><br>';
									echo $lang["example2_xss_text_4"].'<br><br>';
									echo '<u>'.$lang["example2_xss_metod2"].'</u><br><br>';
									echo $lang["example2_xss_text_5"].'<br><br>';
									echo '<u>'.$lang["example2_xss_metod3"].'</u><br><br>';
									echo $lang["example2_xss_text_6"].'<br><br>';
									echo '<u>'.$lang["example2_xss_metod4"].'</u><br><br>';
									echo $lang["example2_xss_text_7"].'<br>';
								}
							}
						}
							break;
						default:
							echo $lang["example_error"];
					}
				}
			?>	
			<br><hr><a class="ui-btn ui-icon-carat-l ui-btn-icon-left ui-corner-all ui-btn-inline" style="float:left;" href="/xss" rel="external"> <?php echo $lang["informations"]; ?> </a>
		</div>