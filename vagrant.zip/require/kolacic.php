<?php
	if(isset($_COOKIE["language"]) && ($_COOKIE["language"] == "hrvatski" || $_COOKIE["language"] == "english"))
	{	
		if(isset($_POST["jezik"]) && ($_POST["jezik"] == "hrv" || $_POST["jezik"] == "eng"))
		{	
			switch($_POST["jezik"])
			{	
				case "eng": 
				{
					setcookie("language", "english", time() + (7*24*60*60*1000),"/","",FALSE,TRUE);
					$_COOKIE["language"] = "english";
				}
				break;
				default:
				{
					setcookie("language", "hrvatski", time() + (7*24*60*60*1000),"/","",FALSE,TRUE);
					$_COOKIE["language"] = "hrvatski";
				}
			}
		}

		switch($_COOKIE["language"])
		{
			case "english":
			{
				if (!is_readable("../lang/eng.php")) 
				{
					http_response_code(503);
					echo '<h1>503 Service Unavailable</h1>';
					exit();
				}
				else require("../lang/eng.php");
			}
				break;
			default:
			{
				if (!is_readable("../lang/hr.php")) 
				{
					http_response_code(503);
					echo '<h1>503 Service Unavailable</h1>';
					exit();
				}
				else require("../lang/hr.php");
			}
		}
	}
	else
	{	
		setcookie("language", "hrvatski", time() + (7*24*60*60*1000),"/","",FALSE,TRUE);
		$_COOKIE["language"] = "hrvatski";
		if (!is_readable("../lang/hr.php")) 
				{
					http_response_code(503);
					echo '<h1>503 Service Unavailable</h1>';
					exit();
				}
		else require("../lang/hr.php");
	}
?>