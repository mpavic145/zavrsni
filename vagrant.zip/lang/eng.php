<?php
	$lang["get_started"] = "To get started, click on the 'Attacks' in the footer and, after redirection, select the attack you want to know more about.";
	$lang["attacks"] = "Attacks";
	$lang["contact"] = "Contact";
	$lang["about"] = "About us";
	$lang["more"] = "For more informations click on :";
	$lang["examples"] = "Examples";
	$lang["types"] = "Types of XSS";
	$lang["author"] = "Author";
	$lang["about_author"] = "My name is Marko Pavić. I am 22 years old. I am a student of the third year at TVZ (computer science study, department of computer systems engineering and networks). I've always been interested in web security, so I decided to make my bachelor's thesis on this subject in order to learn more, and to help others in same thing by bringing everything about it in one place.";	
	$lang["about_tvz"] ="Polytechnic of Zagreb (Latin: Polytechnicum Zagrabiense) is the largest polytechnic in Croatia and it was founded on May 27, 1998. Polytechnic conducts professional and specialist studies some of whom have a much longer tradition, even more than 40 years.";
	$lang["goal"] = "Application purpose";
	$lang["about_goal"] = "The application is made for the purpose of the bachelor's thesis of undergraduate computer science professional studies at TVZ on the subject of 'Web security'. As well as offering general information about the attacks, application also offers learning through ready-made examples and security solutions.";
	$lang["submit"] = "Submit";
	$lang["name"] = "Full name:";
	$lang["email"] = "Email:";
	$lang["query"] = "Your query:";
	$lang["advice"] = "Please send us your questions, commendations, objections or requests through the attached form.";
	$lang["db_error"] = "Problems with database";
	$lang["informations"] = "Info";
	$lang["instructions"] = "Select one of offered options for a detailed explanation of its effect as well as security solutions to prevent it.";
	$lang["code"] = "Examples of malicious code";
	$lang["users"] ="users";
	$lang["example_error"] = "Example is not implemented.";
	$lang["example_number0"] = "Example 0";
	$lang["example_number1"] = "Example 1";
	$lang["example_number2"] = "Example 2";
	$lang["example_text_1"] = "In case the attacker completes the form as in the following picture:";
	$lang["example_text_2"] = "Protection methods (sorted from the worst to the best)";
	
	
	$lang["example_sql_text_1"] = "The most common situation is login form.";
	$lang["example_sql_text_2"] = "Data from form is processed as follows:";
	$lang["example_sql_text_4"] = "Query to the database will look:";
	$lang["example_sql_text_5"] = "This query is always true ('1 = 1'), and by inserting '--' SQL ignores everything that follows after, in this case a password. Since a large number of web applications only verifies whether the number of rows of result received is greater than 0, the verification will pass successfully and the app will accept the login and allow access to other application benefits.Even if the application compares the number of results obtained with the expected number of rows, it is possible to deceive it by limiting the number of rows of results.";
	$lang["example2_sql_text_5"] = "SELECT command is executed and it returns 0 rows, and after it DROP TABLE command is executed. Everything after the characters '--' is ignored. Login here will not pass, but the attacker managed to delete the table users as it was the target.";
	$lang["example_sql_metod1"] = "Parameter type check";
	$lang["example_sql_text_7"] = "Ensures that a place where a whole number is required, for example, does not have a string of characters or a decimal number. In this example, the problem is that parameter is of type string. Strings are checked by a pattern, which is a problem here because the user can use any string of characters as a username so it is almost impossible to implement a good pattern for verification.Such comparison is usually reduced to checking if the string contains invalid characters such as '<>!?#%'.";
	$lang["example_sql_metod2"] = "Permits in the database";
	$lang["example_sql_text_8"] = "In order for a query to be executed at all, you first need to connect to a database as a particular user (different from registered user of applications). If we allow a user only certain actions over the database, we greatly reduce the range of damage they may cause. In this example, if we only allow a user SELECT command over the user table, we would disable any changes to the table users or the rest of the database.  The problem is that this method does not prevent the insertion of additional SELECT commands as well as the manipulation of the basic SELECT command.";
	$lang["example_sql_metod3"] = "Escaping";
	$lang["example_sql_text_9"] = "Using the real_escape_string() function, the replacement of special characters (characters that are important for creating SQL queries) with an imprecise sign will occur. The problem is that it works only when there is a connection to the database.";
	$lang["example_sql_metod4"] = "Object-relational mapping";
	$lang["example_sql_text_10"] = "Using object-relational mapping libraries avoids the need to write SQL code. The ORM library in effect will generate parameterized SQL statements from object-oriented code..";
	$lang["example_sql_metod5"] = "Prepared statements";
	$lang["example_sql_text_11"] = "The input parameters are linked to the SQL query. This prevents the input parameter from becoming a part of SQL query. This method is most commonly used because it prevents manipulation of the basic SQL queries and insertion a new ones, and it is easier to implement it from the object-relational mapping method.";

	
	$lang["example0_xss_text_1"] = "The following code is used to let the user choose his/her preferred language with default language option included.";
	$lang["example0_xss_text_2"] = "The page is invoked with a URL such as:"; 
	$lang["example0_xss_text_3"] = "A DOM Based XSS attack against this page can be accomplished by the following URI:";
	$lang["example0_xss_text_4"] = "Because URI fragment (the part in the URI after the '#') is not sent to the server by the browser, server will receive legimate HTTP Request and provide HTTP Response, but URI will not change that is, it will still contain malicious code. Browser will build a DOM object that contains a document.location object that contains a malicious code. The original Javascript code in the page does not expect the default parameter to contain HTML markup, and as such it simply echoes it into the page (DOM) at runtime. The browser then renders the resulting page and executes the malicious script.";
	$lang["example0_xss_metod1"] = "Trusting the browser";
	$lang["example0_xss_text_5"] = "Although some browsers automatically encode the '<' and '>' characters in the document.URL (for example, Mozilla Firefox encodes them in %3C and %3E), it's never wise to think that the browser itself will protect you. Although the firefox is safe from the above attack, it is not from an attack that does not use the characters in question.";
	$lang["example0_xss_metod2"] = "Same origin policy";
	$lang["example0_xss_text_6"] = "Under the policy, a web browser permits scripts contained in a first web page to access data in a second web page, but only if both web pages have the same origin. An origin is defined as a combination of URI scheme, hostname, and port number. This policy prevents a malicious script on one page from obtaining access to sensitive data on another web page through that page's DOM.";	
	$lang["example0_xss_metod3"] = "Intrusion Prevention Systems";
	$lang["example0_xss_text_7"] = "Employing a very strict IPS policy in which, for example, page page.html is expected to receive a one only parameter named 'default', whose content is inspected, and any irregularity (including excessive parameters or no parameters) results in not serving the original page. This only works if attacker sends malicious code inside HTTP Request. In our example that wasn't the case.";
	$lang["example0_xss_metod4"] = "Sandbox";
	$lang["example0_xss_text_8"] = "Security mechanism for separating running programs. A sandbox provides a tightly controlled set of resources for guest programs or codes to run in. Most major browser have sandbox, but for example Mozilla Firefox doesn't although it is expected in version 54 (current vesion 53).";
	$lang["example0_xss_metod5"] = "Remediation of client-side codes";
	$lang["example0_xss_text_9"] = "The logic behind this attack is that an input from the user (source) goes to an execution point (sink). DOM XSS will appear when a source that can be controlled by the user is used in a dangerous sink. Solutions is validation, encoding or using the right sink. For example, instaed .innerHTML use .innerText/textContent.";
	$lang["example0_xss_metod6"] = "Avoid using client-side data";
	$lang["example0_xss_text_10"] = "Avoid overwriting, redirecting, or other sensitive actions on client-side documents using client-side data.";
	$lang["example0_xss_metod7"] = "Cookie";
	$lang["example0_xss_text_11"] = "Since most of these attacks are targeting cookies, it is recommended to use the httponly cookie parameter. This parameter ensures that the cookie can not be accessed through scripting languages.";
	
	
	$lang["example1_xss_text_1"] = "The most common situations are forms from comments, as well as forum messages. For this example we will use the form for comments.";
	$lang["example1_xss_text_2"] = "Inserted script will be placed in the database in the following format:";
	$lang["example1_xss_text_3"] = "In the case of insecure print of comments:";
	$lang["example1_xss_text_4"] = "The inserted script will be executed:";
	$lang["example1_xss_text_5"] = "In this example, the attacker only prints the cookie, but in the actual attack the attacker will not let the user know that an attack has occurred but instead he will collect cookie by redirecting the user to his own website. The obtained cookie is most likely just the first step of attack. An attack will occur to anyone who access the infected page until a comment containing a malicious script is deleted from the database.";
	$lang["example1_xss_metod1"] = "Parameter type check";
	$lang["example1_xss_text_6"] = "Ensures that a place where a whole number is required, for example, does not have a string of characters or a decimal number. In this example, the problem is that parameter is of type string. Strings are checked by a pattern, which is a problem here because the user can use any string of characters as a username so it is almost impossible to implement a good pattern for verification.Such comparison is usually reduced to checking if the string contains invalid characters such as '<>!?#%'.";
	$lang["example1_xss_metod2"] = "Repairing the input parameter";
	$lang["example1_xss_text_7"] = "By deleting an unacceptable string of characters from a specific string without re-checking after each change, it can be ensured that the remaining text is now a fully valid HTML script element. The attacker will, by trial and error method of comparing his input and obtained output parameter, study the method of repair and adjust his code accordingly.";
	$lang["example1_xss_metod3"] = "Escaping/StripTags/Character Conversion";
	$lang["example1_xss_text_8"] = "By using strip_tags(), htmlspecialchars() or htmlentities() functions, it can be ensured that special characters/tags will lose their specian meanings and become the most common string of characters. Recommendation: The function strip_tags() should always be used before saving the input parameter into the database. Prepared statements that solve SQL Injection problem do not help in this situations. The htmlspecialchars() or htmlentities() function must always be used when printing from the database. Note: If the data obtained from the database is not used for the purpose of printing, but for some other purpose, it is necessary to re-do the validation.";
	$lang["example1_xss_metod4"] = "Whitelist filtering";
	$lang["example1_xss_text_9"] = "Checking whether the input parameter contains only permissible values. If it does not contain, the request should be completely rejected. Do not even use a blacklist that checks if the input parameter contains invalid values, because it is not possible to predict any unexpected data that leaves space that attackers can take advantage of. Note: Where filtering in needed, always filter before validation, and never after.";
	$lang["example1_xss_metod5"] = "Cookie";
	$lang["example1_xss_text_10"] = "Since most of these attacks are targeting cookies, it is recommended to use the httponly cookie parameter. This parameter ensures that the cookie can not be accessed through scripting languages.";
	
	
	$lang["example2_xss_text_1"] = "One of the most basic examples is the form for searching content.";
	$lang["example2_xss_text_2"] = "The search result page also prints the search term:";
	$lang["example2_xss_text_3"] = "The XSS term will be printed and the malicious script will be executed. Only thing left for an attacker to do is lead user to a website which will input his/her malicious code into itself while it is generating.";
	$lang["example2_xss_metod1"] = "Trusting the browser";
	$lang["example2_xss_text_4"] = "Although some browsers automatically encode the '<' and '>' characters in the document.URL (for example, Mozilla Firefox encodes them in %3C and %3E), it's never wise to think that the browser itself will protect you. Although the firefox is safe from the above attack, it is not from an attack that does not use the characters in question.";
	$lang["example2_xss_metod2"] = "Intrusion Prevention Systems";
	$lang["example2_xss_text_5"] = "Employing a very strict IPS policy in which, for example, page results.html is expected to receive a one only parameter named 'search', whose content is inspected, and any irregularity (including excessive parameters or no parameters) results in not serving the original page. This only works if attacker sends malicious code inside HTTP Request. In our example that wasn't the case.";
	$lang["example2_xss_metod3"] = "Validation/Filtering/Escaping";
	$lang["example2_xss_text_6"] = "For filtering always use whitelist. Do not even use a blacklist that checks if the input parameter contains invalid values, because it is not possible to predict any unexpected data that leaves space that attackers can take advantage of. Note: Where filtering in needed, always filter before validation, and never after. With validation it is recommended to use escaping functions.";
	$lang["example2_xss_metod4"] = "Cookie";
	$lang["example2_xss_text_7"] = "Since most of these attacks are targeting cookies, it is recommended to use the httponly cookie parameter. This parameter ensures that the cookie can not be accessed through scripting languages.";
?>