		<div data-role="main" class="ui-content" style="padding:1em;">
		
			<?php echo $lang["instructions"] ?>
		
			<form method="post" action="#" rel="external">
				<fieldset class="ui-field-contain">
					<label for="injection"> <?php echo $lang["code"] ?> </label>
					<select name="injection" id="injection">
						<option value="example_1">' OR '1'='1' -- </option>
						<option value="example_2">a';DROP TABLE <?php echo $lang["users"] ?> --</option>
					</select>
				</fieldset>
				<input type="submit" value=" <?php echo $lang["submit"] ?> " data-icon="check" data-iconpos="right" data-inline="true">
				<br><hr>
			</form>

			<?php
			
				if(isset($_POST["injection"]))
				{	
					switch($_COOKIE["language"])
					{
						case "hrvatski":
							$jezik= "hrv";
							break;
						case "english":
							$jezik= "eng";
							break;
						default:
							$jezik= "hrv";
					}
					
					switch($_POST["injection"])
					{
						case "example_1":
						{	
							echo '<h3>'.$lang["example_number1"].'</h3>';
							echo $lang["example_sql_text_1"].'<br>';
							
							switch($jezik)
							{
								case "eng":
								{
									echo '<img src="../img/login_eng.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_2"].'<br>';
									echo '<img src="../img/form_eng.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/login_injection_eng.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_4"].'<br>';
									echo '<img src="../img/query_eng.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_5"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example_sql_metod1"].'</u><br><br>';
									echo $lang["example_sql_text_7"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod2"].'</u><br><br>';
									echo $lang["example_sql_text_8"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod3"].'</u><br><br>';
									echo $lang["example_sql_text_9"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod4"].'</u><br><br>';
									echo $lang["example_sql_text_10"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod5"].'</u><br><br>';
									echo $lang["example_sql_text_11"].'<br>';
								}
								break;
								default:
								{
									echo '<img src="../img/login.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_2"].'<br>';
									echo '<img src="../img/form.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/login_injection.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_4"].'<br>';
									echo '<img src="../img/query.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_5"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example_sql_metod1"].'</u><br><br>';
									echo $lang["example_sql_text_7"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod2"].'</u><br><br>';
									echo $lang["example_sql_text_8"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod3"].'</u><br><br>';
									echo $lang["example_sql_text_9"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod4"].'</u><br><br>';
									echo $lang["example_sql_text_10"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod5"].'</u><br><br>';
									echo $lang["example_sql_text_11"].'<br>';
								}
							}
						}
							break;
						
						case "example_2":
						{
							echo '<h3>'.$lang["example_number2"].'</h3>';
							echo $lang["example_sql_text_1"].'<br>';
							
							switch($jezik)
							{
								case "eng":
								{
									echo '<img src="../img/login_eng.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_2"].'<br>';
									echo '<img src="../img/form_eng.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/login_injection2_eng.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_4"].'<br>';
									echo '<img src="../img/query2_eng.png" style="width:100%;"><br>';
									echo $lang["example2_sql_text_5"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example_sql_metod1"].'</u><br><br>';
									echo $lang["example_sql_text_7"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod2"].'</u><br><br>';
									echo $lang["example_sql_text_8"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod3"].'</u><br><br>';
									echo $lang["example_sql_text_9"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod4"].'</u><br><br>';
									echo $lang["example_sql_text_10"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod5"].'</u><br><br>';
									echo $lang["example_sql_text_11"].'<br>';
								}
								break;
								default:
								{
									echo '<img src="../img/login.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_2"].'<br>';
									echo '<img src="../img/form.png" style="width:100%;"><br>';
									echo $lang["example_text_1"].'<br>';
									echo '<img src="../img/login_injection2.png" style="width:100%;"><br>';
									echo $lang["example_sql_text_4"].'<br>';
									echo '<img src="../img/query2.png" style="width:100%;"><br>';
									echo $lang["example2_sql_text_5"].'<br>';
									echo '<h3>'.$lang["example_text_2"].'</h3>';
									echo '<u>'.$lang["example_sql_metod1"].'</u><br><br>';
									echo $lang["example_sql_text_7"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod2"].'</u><br><br>';
									echo $lang["example_sql_text_8"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod3"].'</u><br><br>';
									echo $lang["example_sql_text_9"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod4"].'</u><br><br>';
									echo $lang["example_sql_text_10"].'<br><br>';
									echo '<u>'.$lang["example_sql_metod5"].'</u><br><br>';
									echo $lang["example_sql_text_11"].'<br>';
								}
							}
						}
							break;
						default:
							echo $lang["example_error"];
					}
				}
			?>
			<br><hr><a class="ui-btn ui-icon-carat-l ui-btn-icon-left ui-corner-all ui-btn-inline" style="float:left" href="/sql_injection" rel="external"> <?php echo $lang["informations"]; ?> </a>
		</div>