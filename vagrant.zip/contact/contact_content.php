		<div data-role="main" class="ui-content" style="padding:1em;">
			<div>
				<?php echo $lang["advice"].'<br><hr>'; ?>
			</div>
			<div class="ui-field-contain">
				<form method="post" action="#" rel="external">	
					<label for="fullname"> <?php echo $lang["name"] ?> </label>
					<input type="text" id="fullname" name="fullname" required autocomplete="off" data-clear-btn="true"><br>
					<label for="email"> <?php echo $lang["email"] ?> </label>
					<input type="email" id="email" name="email" required autocomplete="off" data-clear-btn="true"><br>
					<label for="query"> <?php echo $lang["query"] ?> </label>
					<textarea name="query" id="query" required autocomplete="off"></textarea>
					<input type="submit" value=" <?php echo $lang["submit"] ?> " data-icon="check" data-iconpos="right" data-inline="true">
				</form>
			</div>
  		
			<?php
				if(isset($_POST["fullname"]) && isset($_POST["email"]) && isset($_POST["query"]))
				{	
					if (!is_readable("../require/idiorm.php")) 
					{
						http_response_code(503);
						echo '<h1>503 Service Unavailable</h1>';
						exit();
					}
					else require("../require/idiorm.php");
					
					$fullname=strip_tags($_POST["fullname"]);
					$email=strip_tags($_POST["email"]);
					$querytext=strip_tags($_POST["query"]);
					
					try
					{
						ORM::configure(array(
							'connection_string' => 'mysql:host=localhost;dbname=zavrsni',
							'username' => 'ins',
							'password' => 'upisi'));
						ORM::configure('return_result_sets', true);
						ORM::configure('driver_options', array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
						ORM::configure('error_mode', PDO::ERRMODE_EXCEPTION);
						
						$query = ORM::for_table('upiti')->create();
						
						$query->FullName = $fullname;
						$query->Email = $email;
						$query->QueryText = $querytext;
						
						$query->save();

					}
					catch(PDOException $e)
					{
						echo $lang["db_error"];
					}
					catch (Exception $e) 
					{
					  echo $lang["db_error"];
					}
				}
			?>
		</div>