		<div data-role="main" class="ui-content" style="padding:1em;">
			<?php
				$files = ["../require/idiorm.php", "../require/library/HTMLPurifier.auto.php"];

				foreach ($files as $file) 
				{
					if (!is_readable($file)) 
					{
						http_response_code(503);
						echo '<h1>503 Service Unavailable</h1>';
					}
				}

				foreach ($files as $file) 
				{
					require $file;
				}
				
				$purifier = new HTMLPurifier();
				$tag = "home";
				
				switch($_COOKIE["language"])
				{
					case "hrvatski":
						$jezik= "hrv";
						break;
					case "english":
						$jezik= "eng";
						break;
					default:
						$jezik= "hrv";
				}

				try
				{
					ORM::configure(array(
						'connection_string' => 'mysql:host=localhost;dbname=zavrsni',
						'username' => 'inf',
						'password' => 'opis'));
					ORM::configure('return_result_sets', true);
					ORM::configure('driver_options', array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES utf8'));
					ORM::configure('error_mode', PDO::ERRMODE_EXCEPTION);
									
					$query = ORM::for_table('opce_informacije')->where(array('Lang' => $jezik,'Tag' => $tag))->find_one();
					
					$clean_html = $purifier->purify($query->Info);

					echo $clean_html;
				}
				catch(PDOException $e)
				{
					echo $lang["db_error"];
				}
				catch (Exception $e) 
				{
					echo $lang["db_error"];
				}
				
				echo '<br><br>'.$lang["get_started"];
			?>
  		</div>