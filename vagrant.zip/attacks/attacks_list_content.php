		<div data-role="main" class="ui-content" style="padding:1em;">
			<div class="ui-grid-a ui-responsive" style="text-align:center;">
				<div class="ui-block-a" style="padding:1em;">
					<span>SQL Injection</span>
					<img src="../img/sqlia.png" style="width:98%;">
					<div class="ui-grid-a">
						<div class="ui-block-a"><a href="../sql_injection" class="ui-btn ui-btn-icon-top ui-shadow ui-corner-all ui-icon-info ui-mini" rel="external"> <?php echo $lang["informations"] ?> </a></div>
						<div class="ui-block-b"><a href="../sql_injection/examples" class="ui-btn ui-btn-icon-top ui-shadow ui-corner-all ui-icon-eye ui-mini" rel="external"> <?php echo $lang["examples"] ?> </a></div>
					</div>
				</div>
				<div class="ui-block-b" style="padding:1em;">
					<span>Cross-site Scripting</span>
					<img src="../img/code_client.png" style="width:98%;"> 
					<div class="ui-grid-a">
						<div class="ui-block-a"><a href="../xss" class="ui-btn ui-btn-icon-top ui-shadow ui-corner-all ui-icon-info ui-mini" rel="external"> <?php echo $lang["informations"] ?> </a></div>
						<div class="ui-block-b"><a href="../xss/examples" class="ui-btn ui-btn-icon-top ui-shadow ui-corner-all ui-icon-eye ui-mini" rel="external"> <?php echo$lang["examples"] ?> </a></div>
					</div>
				</div>
			</div>
		</div>