<?php
	error_reporting(0);
	session_start();
	if (!isset($_SESSION["dev"]) || !$_SESSION["dev"] == "edv")
	{
		if (!is_readable("../require/mobile_detect.php")) 
		{
			http_response_code(503);
			echo '<h1>503 Service Unavailable</h1>';
			exit();
		}
		else require("mobile_detect.php");
		$detect = new Mobile_Detect;
		if(!$detect->isMobile() && !$detect->isTablet())
		{
			header("Location: https://www.owasp.org/index.php/Main_Page");
			exit();
		}
		else $_SESSION["dev"] = "edv";
	}
?>	