<?php
	$lang["get_started"] = "Kako bi ste započeli, kliknite na ikonu 'Napadi' u podnožju te, nakon redirekcije, odaberite napad o kojem želite znati više.";
	$lang["attacks"] = "Napadi";
	$lang["contact"] = "Kontakt";
	$lang["about"] = "O nama";
	$lang["more"] = "Za više informacije kliknite na :";
	$lang["examples"] = "Primjeri";
	$lang["types"] = "Tipovi XSS-a";
	$lang["author"] = "Autor";
	$lang["about_author"] = "Zovem se Marko Pavić. Imam 22 godine. Student sam treće godine TVZ-a (studij računarstva, smjer Inženjerstvo računalnih sustava i mreža). Uvijek sam se zanimao za web sigurnost, pa sam odlučio završni rad napraviti na tu temu kako bih se dodatno informirao, a i kako bih i drugima olaškao skupljajući sve o tome na jedno mjesto.";
	$lang["about_tvz"] ="Tehničko veleučilište u Zagrebu (latinski: Polytechnicum Zagrabiense) je najveće veleučilište u Hrvatskoj osnovano 27. svibnja 1998. godine. Veleučilište izvodi stručne i specijalističke studije gdje pojedini studiji imaju puno dulju tradiciju, neki dulju od 40 godina.";
	$lang["goal"] = "Svrha alikacije";
	$lang["about_goal"] ="Aplikacija je izrađena u svrhu završnog rada redovnog dodiplomskog stručnog studija računarstva na TVZ-u na temu 'Web security'. Osim što nudi uopće informacije o napadima, aplikaciju nudi i učenje kroz gotove primjere i sigurnosna rješenja.";
	$lang["submit"] = "Pošalji";
	$lang["name"] = "Ime i prezime:";
	$lang["email"] = "Email:";
	$lang["query"] = "Vaš upit:";
	$lang["advice"] = "Vaša pitanja, pohvale, prigovore ili zahtjeve pošaljite nam putem priložene forme.";
	$lang["db_error"] = "Problemi s bazom podataka";
	$lang["informations"] ="Info";
	$lang["instructions"] = "Odaberite jednu od ponuđenih opcija za detaljno objašnjenje njenog učinka kao i sigurnosna rješenja kako biste je spriječili.";
	$lang["code"] = "Primjeri zlonamjernog koda";
	$lang["users"] ="korisnici";
	$lang["example_error"] = "Primjer nije implementiran.";
	$lang["example_number0"] = "Primjer 0";
	$lang["example_number1"] = "Primjer 1";
	$lang["example_number2"] = "Primjer 2";
	$lang["example_text_1"] = "U slučaju da napadač ispuni formu kao na sljedećoj slici:";
	$lang["example_text_2"] = "Medote zaštite (sortirane od najlošije do najbolje)";
	
	
	$lang["example_sql_text_1"] = "Najčešća situacija je forma za prijavu.";
	$lang["example_sql_text_2"] = "Podaci iz forme se obrađuju na sljedeći način:";
	$lang["example_sql_text_4"] = "Upit prema bazi izgledat će:";
	$lang["example_sql_text_5"] = "Ovaj upit je uvijek istinit ('1=1'), a umetanjem znakova '--' u SQL-u se ignorira sve što slijedi nakon njih, u ovom slučaju lozinka. Obzirom da dosta web aplikacija samo provjerava da li je broj redova rezultata upita veći od 0, provjera će proći uspješno te će aplikacija prihvatiti prijavu i dozvoliti pristup ostalim pogodnostima aplikacije. Čak i u slučaju da aplikacija uspoređuje broj redova rezultata s očekivanim brojem redova, moguće ju je prevariti limitirajući broj redova rezultata. ";
	$lang["example2_sql_text_5"] = "SELECT naredba će se izvršiti te vratiti 0 redaka,a nakon nje će se izvršiti DROP TABLE naredba. Sve nakon znakova '--' se ignorira. Prijava ovdje neće proći, ali napadač je uspio izbrisati tablicu korisnici što mu je ionako bio cilj.";
	$lang["example_sql_metod1"] = "Provjera tipa parametra";
	$lang["example_sql_text_7"] = "Osigurava da na mjesto, gdje je na primjer potreban cijeli broj, ne dođe niz znakova ili decimalni broj. U ovom primjeru problem je što je tip parametra niz znakova (string). Stringovi se provjeravaju po nekom uzorku, što je ovdje problem obzirom da korisnik može koristiti bilo koji niz znakova kao korisničko ime pa je gotovo nemoguće implementirati dobar uzorak za provjeru. Takva usporedba se najčešće svodi na provjeru da li string sadrži nedozvoljene znakove poput '<>!?#%'.";
	$lang["example_sql_metod2"] = "Dozvole u bazi podataka";
	$lang["example_sql_text_8"] = "Kako bi se uopće upit mogao izvršiti, najprije se potrebno spojiti na bazu podataka kao određeni korisnik (različito od registriranih korisnika aplikacije). Ukoliko dozvolimo korisniku samo određene akcije nad bazom podataka uvelike smanjujemo krug štete koju može nanjeti. U ovom primjeru, ukoliko bismo korisniku dopustili samo SELECT naredbu nad tablicom korisnici, onemogućili bismo bilo kakvo mijenjanje tablice korisnici ili ostatka baze podataka. Problem je što ova metoda ne spriječava ubacivanje dodatnih SELECT naredbi kao i manipulaciju osnovne SELECT naredbe.";
	$lang["example_sql_metod3"] = "Escaping";
	$lang["example_sql_text_9"] = "Koristeći real_escape_string() funckiju dogodit će se zamjena specijalnih znakova (znakova važnih za kreiranje SQL upita) s nebitnim znakom. Problem je što radi samo kada postoji konekcija prema bazi.";
	$lang["example_sql_metod4"] = "Objektno-relacijsko mapiranje";
	$lang["example_sql_text_10"] = "Koristeći biblioteke objektnog-relacijskog mapiranja upotpunosti se uklanja potreba za pisanjem SQL upita. Dotične biblioteke će same izgenerirati sigurne parametrirane SQL upite iz objektnog orijentiranog koda.";
	$lang["example_sql_metod5"] = "Pripremljeni upiti";
	$lang["example_sql_text_11"] = "Ulazni parametri se povezuju na SQL upit. Time se spriječava da ulazni parametar postane dio SQL upita. Ova metoda se najčešće koristi jer istovremeno sprječava manipulaciju osnovnog SQL upita i ubacivanje novog, a i lakše ju je implementirati od metode objektnog-relacijskog mapiranja.";

	
	$lang["example0_xss_text_1"] = "Sljedeći kod koristi se kako bi korisnik odabrao željeni jezik s opcijom zadanog jezika.";
	$lang["example0_xss_text_2"] = "Stranica se poziva preko URL-a poput:";
	$lang["example0_xss_text_3"] = "DOM Based XSS napad na ovu stranicu može se izvesti preko sljedećeg URI-a:";
	$lang["example0_xss_text_4"] = "Budući da preglednik ne šalje poslužitelju URI fragment (dio URI-a nakon '#'), poslužitelj će primiti legitimni HTTP zahtjev i poslati HTTP odgovor, ali URI se neće promijeniti, to jest i dalje će sadržavati zlonamjerni kod. Preglednik će izraditi DOM objekt koji sadrži dokument.location objekt koji pak sadrži zlonamjerni kod.  Izvorni JavaScript kod na stranici ne očekuje da će parametar default sadržavati HTML oznake, pa ih ubacuje u stranicu (DOM) pri izvođenju. Preglednik zatim prikaže dobivenu stranicu i izvršava zlonamjernu skriptu.";
	$lang["example0_xss_metod1"] = "Vjera u preglednik";
	$lang["example0_xss_text_5"] = "Iako neki preglednici automatski kodiraju znakove '<' i '>' u document.URL-u (na primjer Mozilla Firefox-a ih kodira u %3C i %3E), nikada nije pametno smatrati da će vas sam preglednik zaštititi. Iako je firefox siguran od gore prikazanog napada, nije od napada koji ne koristi dotične znakove.";
	$lang["example0_xss_metod2"] = "Politika istog podrijetla";
	$lang["example0_xss_text_6"] = "Prema politici, web preglednik dozvoljava skripte sadržane na prvoj web stranici za pristup podacima na drugoj web stranici, ali samo ako obje web stranice imaju isto podrijetlo. Podrijetlo se definira kao kombinacija URI sheme, naziva računala i broja porta. Ovo pravilo sprječava zlonamjernu skriptu na jednoj stranici da dobije pristup osjetljivim podacima na drugoj web stranici kroz DOM za tu stranicu.";
	$lang["example0_xss_metod3"] = "Intrusion Prevention Systems";
	$lang["example0_xss_text_7"] = "Korištenje vrlo stroge IPS politike u kojoj, na primjer, stranica page.html očekuje primiti jedan jedini parametar 'default', čiji se sadržaj pregledava, i u slučaju bilo kakve nepravilnosti (uključujući prekomjerne parametre ili nepostojanje parametara) ne isporučuje originalnu stranicu. To funkcionira samo ako napadač šalje zlonamjerni kod unutar HTTP zahtjeva. U našem primjeru to nije bio slučaj.";
	$lang["example0_xss_metod4"] = "Sandbox";
	$lang["example0_xss_text_8"] = "Sigurnosni mehanizam za odvajanje pokrenutig programa. Sandbox osigurava čvrsto kontrolirani skup resursa za pokretanje programa ili kodova gosta. Većina velikih preglednika ima sandbox, ali na primjer Mozilla Firefox nema, iako se očekuje u verziji 54 (trenutačna verzija 53).";	
	$lang["example0_xss_metod5"] = "Saniranje klijent-side kodova";
	$lang["example0_xss_text_9"] = "Logiku iza ovog napada predstavlja unos korisnika (source) koji ide do točke izvođenja (sink). DOM XSS će se pojaviti kada se izvor, koji korisnik može kontrolirati, koristi u opasnoj točki izvođenja. Rješenja su validacija, kodiranje ili korištenje prave točke izvođenja. Na primjer, umjesto .innerHTML koristite .innerText/textContent.";
	$lang["example0_xss_metod6"] = "Izbjegavanje korištenje klijent-side podataka";
	$lang["example0_xss_text_10"] = "Izbjegavajte prepisivanje, preusmjeravanje ili druge osjetljive radnje nad klijent-side dokumentima pomoću klijent-side podataka.";
	$lang["example0_xss_metod7"] = "Cookie";
	$lang["example0_xss_text_11"] = "Obzirom da većina ovakvih napada cilja cookie, preporuča se korištenje httponly parametra cookie-a. Dotični parametar osigurava da se cookie-u ne može pristupiti preko skriptnih jezika.";

	
	$lang["example1_xss_text_1"] = "Najčešće situacije su forme za komentare, kao i poruke na forumima. Za ovaj primjer koristit ćemo formu za komentare.";
	$lang["example1_xss_text_2"] = "Ubačena skripta će se nalaziti u bazi podataka u sljedećem obliku:";
	$lang["example1_xss_text_3"] = "U slučaju nesigurnog ispisa komentara:";
	$lang["example1_xss_text_4"] = "Ubačena skripta će se izvršiti:";
	$lang["example1_xss_text_5"] = "U ovom primjeru napadač samo ispisuje cookie, ali u pravom napadu napadač neće dati do znanja da je došlo do napada, već će sakupiti kolačić preusmjeravanjem korisnika na vlastitu web stranicu. Dobiveni kolačić najvjerojatnije je samo prvi korak napada. Napad će zadesiti svakoga tko pristupi zaraženoj stranici sve dok se komentar, koji u sebi sadrži zlonamjernu skriptu, ne izbriše iz baze podataka.";
	$lang["example1_xss_metod1"] = "Provjera tipa parametra";
	$lang["example1_xss_text_6"] = "Osigurava da na mjesto, gdje je na primjer potreban cijeli broj, ne dođe niz znakova ili decimalni broj. U ovom primjeru problem je što je tip parametra niz znakova (string). Stringovi se provjeravaju po nekom uzorku, što je ovdje problem obzirom da korisnik može koristiti bilo koji niz znakova kao korisničko ime pa je gotovo nemoguće implementirati dobar uzorak za provjeru. Takva usporedba se najčešće svodi na provjeru da li string sadrži nedozvoljene znakove poput '<>!?#%'.";
	$lang["example1_xss_metod2"] = "Popravak ulaznog parametra";
	$lang["example1_xss_text_7"] = "Izbacivanjem neprihvatljivog niza znakova iz specifičnog stringa bez ponovne provjere nakon svake promjene može se osigurati da je preostali tekst sada u cijelosti važeći element HTML skripte. Napadač će metodom pokušaja i pogrešaka, uspoređujući njegov ulazni i dobiveni vanjski parametar, proučiti metodu popravka te će prilagoditi svoj kod u skladu s tim.";
	$lang["example1_xss_metod3"] = "Escaping/Skidanje tagova/Konverzija znakova";
	$lang["example1_xss_text_8"] = "Koristeći funkcije strip_tags() te htmlspecialchars() ili htmlentities() osigurava se da specijalni znakovi/tagove izgube svoj specijalan značaj te da postanu najobičniji niz znakova. Preporuka: funkciju strip_tags() treba uvijek koristiti prije spremanja ulaznog parametra u bazu podataka. Pripremljeni upiti koji rješavaju problem SQL Injection ne pomažu u ovakvom slučaju. Funckiju htmlspecialchars() ili htmlentities() treba uvijek koristiti pri ispisu iz baze. Napomena: ukoliko se podatak, dobiven iz baze podataka, ne koristi u svrhu ispisa, nego u neku drugu svrhu, potrebno je ponovno provjesti validaciju.";
	$lang["example1_xss_metod4"] = "Bijela lista filtiranja";
	$lang["example1_xss_text_9"] = "Provjera se da li ulazni parametar sadrži samo dopuštene vrijednosti. Ukoliko ne sadrži, treba odbaciti zahtjev u potpunosti. Nikako ne koristiti crnu listu, koja provjerava da li ulazni parametar sadrži nedozvoljene vrijednosti, jer nije moguće predvidjeti sve moguće neočekivane podatke što ostavlja prostor koji napadači mogu iskoristiti. Napomena: Gdje se mora filtrirati, uvijek treba filtrirati prije validacije, a nikad poslije.";
	$lang["example1_xss_metod5"] = "Cookie";
	$lang["example1_xss_text_10"] = "Obzirom da većina ovakvih napada cilja cookie, preporuča se korištenje httponly parametra cookie-a. Dotični parametar osigurava da se cookie-u ne može pristupiti preko skriptnih jezika.";

	
	$lang["example2_xss_text_1"] = "Jedan od najosnovnijih primjera je forma za pretraživanje sadržaja.";
	$lang["example2_xss_text_2"] = "Stranica za prikaz rezultata također ispisuje traženi pojam:";
	$lang["example2_xss_text_3"] = "Pojam XSS će se ispisati, a zlonamjerna skripta izvršiti. Napadaču preostaje samo navesti korisnika na stranicu koja će u sebe, prilikom generiranja, ubaciti njegov/njezin zlonamjerni kod.";
	$lang["example2_xss_metod1"] = "Vjera u preglednik";
	$lang["example2_xss_text_4"] = "Iako neki preglednici automatski kodiraju znakove '<' i '>' u document.URL-u (na primjer Mozilla Firefox-a ih kodira u %3C i %3E), nikada nije pametno smatrati da će vas sam preglednik zaštititi. Iako je firefox siguran od gore prikazanog napada, nije od napada koji ne koristi dotične znakove.";
	$lang["example2_xss_metod2"] = "Intrusion Prevention Systems";
	$lang["example2_xss_text_5"] = "Korištenje vrlo stroge IPS politike u kojoj, na primjer, stranica page.html očekuje primiti jedan jedini parametar 'default', čiji se sadržaj pregledava, i u slučaju bilo kakve nepravilnosti (uključujući prekomjerne parametre ili nepostojanje parametara) ne isporučuje originalnu stranicu. To funkcionira samo ako napadač šalje zlonamjerni kod unutar HTTP zahtjeva. U našem primjeru to nije bio slučaj.";
	$lang["example2_xss_metod3"] = "Validacija/Filtiranje/Escaping";
	$lang["example2_xss_text_6"] = "Za filtiranje koristiti bijelu listu. Nikako ne koristiti crnu listu, koja provjerava da li ulazni parametar sadrži nedozvoljene vrijednosti, jer nije moguće predvidjeti sve moguće neočekivane podatke što ostavlja prostor koji napadači mogu iskoristiti. Napomena: Gdje se mora filtrirati, uvijek treba filtrirati prije validacije, a nikad poslije. Uz validaciju se preporuča korištenje i escaping funkcija.";
	$lang["example2_xss_metod4"] = "Cookie";
	$lang["example2_xss_text_7"] = "Obzirom da većina ovakvih napada cilja cookie, preporuča se korištenje httponly parametra cookie-a. Dotični parametar osigurava da se cookie-u ne može pristupiti preko skriptnih jezika.";
?>